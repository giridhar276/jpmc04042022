

import boto3
aws_mag_con=boto3.session.Session(profile_name="user30")
iam_re = aws_mag_con.resource(service_name = 'iam')

for value in range(101,120):
    iam_re.create_user(UserName = "user" + str(value))
    print("user" + str(value) , "created")
