

 
import requests
import json
 

url = 'https://api.github.com/'

endpoint = "gists"

finalurl  = url + endpoint

user = "giridhar276"

filename = "oop11.py"

# reading the file in string format
with open(filename,"r") as fobj:
    mydata = fobj.read()
    
    
payload = {
    "description": "rest api example",
    "public" : "true",
    'user' : user,
    "files" :{
                "oop11.py" :{
                    "content":mydata
                    }   

        }
    }

response = requests.post(finalurl , data = json.dumps(payload) ,auth = ("giridhar276","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"))

print(response)
if response.status_code == 201 :
    print(response.text)




