
#tuple
#tuple contains set of elements.
#Elements can be set of numbers or strings or any combination


alist = [45,43,45]
alist[0] = 100
print("after replacing :", alist)



atup = (34,45,3234,43)
#atup[0] = 3000
print("After replacing :", atup)

# type casting - converting from one object to another obj
alist = list(atup)
alist.append(432)
atup = tuple(alist)
print("After replacing :", atup)





name = "python"
name[0] = "z"
print("after replacing :", name)
