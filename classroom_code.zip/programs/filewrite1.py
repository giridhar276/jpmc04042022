
# traditional way  # legacy way
fobj = open("numbers1.txt","w")
for val in range(1,10):
    fobj.write(str(val) + "\n")
    
fobj.close()



# context manager
# file gets closed automaticaly

with open("numbers1.txt","w") as fobj:
    for val in range(1,10):
        fobj.write(str(val) + "\n")
        
        
