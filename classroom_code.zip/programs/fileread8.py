

import csv
import sys
import json

try:
    with open("employee_multiple1.json") as fobj:
        data = json.load(fobj)
        #print(data)
        output = data['users']
        header = list(output[0].keys())

    with open("employees.csv", 'w') as csvfile: 
        writer = csv.DictWriter(csvfile, fieldnames = header) 
        writer.writeheader() 
        writer.writerows(output) 
        
except Exception as err:
    print(err)
    print(sys.exc_info())
    


        