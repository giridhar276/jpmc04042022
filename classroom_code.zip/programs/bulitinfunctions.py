


name = input('Enter any string :')
print("user input :", name)


aname = "python"
print(len(aname))

alist = [10,20,30]
print(len(alist))

print(max(alist))
print(min(alist))
print(sum(alist))

print(type(alist))


print(isinstance(alist,list))
print(isinstance(alist,str))
print(isinstance(alist,tuple))


print(id(alist))
print(id(name))


alist = [10,20,30]
blist = [10,20,30]

print(id(10))
print(id(alist[0]))
print(id(blist[0]))

print(id(alist))
print(id(blist))


