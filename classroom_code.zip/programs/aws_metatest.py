

# create resource object and access client methods using meta
# convert resource object to client object

import boto3 
import time
aws_con=boto3.session.Session(profile_name="user30")
#resource
ec2_con_re=aws_con.resource(service_name="ec2")


for each_item in ec2_con_re.meta.client.describe_regions()['Regions']:
    print(each_item['RegionName'])