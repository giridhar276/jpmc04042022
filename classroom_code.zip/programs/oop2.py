
# every class contains data members and member functions
class Employee:
    def getemployee(self,name,age,location):
        self.name = name   
        self.age = age
        self.location = location
    
    def displayEmployee(self):
        print("Name :",self.name)
        print("Age  :", self.age)
        print("Location :",self.location)
        
# object creation 
# object initialiation
emp1 = Employee()
emp1.getemployee('Ram',30,"Hyd")
emp1.displayEmployee()
print(emp1.name)

emp2 = Employee()
emp2.getemployee('Rita',25,"US")
emp2.displayEmployee()
print(emp2.name)