print(10,20,30)
print("unix")

name = "python programming language"
print(name.upper())

print(name.lower())
print(name.capitalize())

print(name.count("p"))

print(name.startswith("p"))
print(name.startswith("y"))
print(name.endswith("g"))
print(name.endswith("y"))



print(name.split(" "))

aname = " python    "
print(len(aname))
print(len(aname.strip()))
print(len(aname.lstrip()))
print(len(aname.rstrip()))

print(name.replace("python","ruby"))

data = "I love {} and {}"

print(data.format("python","scala"))
print(data.format("1","2"))


# convert list to string
alist = ["java","oracle","unix"]
name = "-".join(alist)
print(name)















a,b = 100,20
if a < b:
    print("A is less than B")
    print("Inside if")
    print("Still inside if")
else:
    print("B is less than B")
    print("inside else")
    print("still inside else")
print("regular program")



name = "python programming"
if name.startswith("p") :
    print("its python")
elif name.startswith("j"):
    print("its java programming")
elif name.startswith("unix"):
    print("its unix")
else:
    print("Its C langauge")
    


if name.isupper():
    print("uppercase")
else:
    print("lowercase")


#iterating
for val in range(1,11):
    print(val)



name = "python"
for char in name:
    print(char)
    
# string slicing
# string[start:stop:step]
name = "python programming"
print(name[0])
print(name[1])
print(name[0:5])
print(name[::])
print(name)
print(name[:])
print(name[0:18:2])
print(name[1:18:2])
print(name[-1])  # g
print(name[-2])  # n
print(name[::-1])
















































