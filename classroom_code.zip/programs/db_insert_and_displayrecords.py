
import pymysql
import os
import sys
import csv
import boto3

class Database:
    def __init__(self,hostname,port,username,password,database):
        self.hostname = hostname
        self.port = port
        self.username = username
        self.password = password 
        self.database = database
    
    def connect(self):
        try:
            self.db = pymysql.connect(host=self.hostname,port=self.port,user=self.username,password=self.password ,database=self.database)
            print(self.db)
        except pymysql.err.InternalError as err:
            print(err)
        except Exception as err:
            print(err)
            
    def createCursor(self):
        self.cursor = self.db.cursor()
    def displayData(self):
        try:
            self.query = "select * from realestate"
            self.cursor.execute(self.query)
            for record in self.cursor.fetchall():
                print("Street :",record[0] )
                print("City   :",record[1])
        except pymysql.err.DataError as err:
            print(err)
    def closeConnection(self):
        self.db.close()
    
    
    def insertData(self,file):
        self.file = file
        #validations
        if os.path.isfile(self.file) and os.path.getsize(self.file) > 0 :
            with open(self.file,"r") as self.obj:
                # convert file object to csv object
                self.reader = csv.reader(self.obj)
                for record in self.reader:
                    street = record[0]
                    city = record[1]
                    print(street,city)
                    self.query = "insert into realestate values('{}','{}')".format(street,city)
                    self.cursor.execute(self.query)
                self.db.commit()
        else:
            return "file not exists"
        
# validation for bucket
# valiate where the file exists in the bucket   
    
  
    def downloadFile(self,profile_name,file):
        # your download
        self.profile_name = profile_name
        self.file = file
        self.session=boto3.session.Session(profile_name= self.profile_name)
        self.s3 = self.session.resource("s3")
        self.s3.Bucket('giri12042022').download_file( self.file,self.file)
        
        
        

if __name__ == "__main__":
    db1 = Database('localhost',3306,'root','india@123','jpmc')
    status = db1.connect()
    db1.createCursor()
    filename = "realestate.csv"
    profile_name = 'user30'
    db1.downloadFile(profile_name,filename)
    returnString =  db1.insertData(filename)
    if returnString != "file not exists":
        db1.displayData()
        
        
    #### 
    # connect to database and
    #  write all the records to the citysacramento.csv where the city is SACRAMENTO
    db1.onlySACRAMENTO()  
    # upload citysacramento.csv to the s3 bucket
    db1.updateProcessedFile()
    db1.closeConnection()
    
    
    







    
    
    
    