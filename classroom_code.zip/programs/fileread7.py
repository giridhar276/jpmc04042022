
try:
    with open("employee_multiple1.json", "r") as file:
        data = json.load(file)
        for key,value in data.items():
            employee_data = value

        with open("employees1.csv","w") as fw:
            for i in range(0, len(employee_data)):
                employee_details = list(employee_data[i].values())
                emp = ",".join(map(str, employee_details))
                fw.write(emp + "\n")
except FileNotFoundError as e:
    print("File is not found: ", e)
    