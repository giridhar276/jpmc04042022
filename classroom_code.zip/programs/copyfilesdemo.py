
'''
create 2 folders in your current directory

source     : copy few files to the source foldre
destination: 

write a program to copy all the files from source folder to the destination folder.

'''

import os
import shutil
source = r'D:\trainings\jpmc04042022\programs\source'
destination = r'D:\trainings\jpmc04042022\programs\destination'


currentdir = os.getcwd()
if not os.path.exists(destination):
    os.mkdir(destination)
        
os.chdir(source)

if os.path.exists(source):
    for file in os.listdir(source):
        shutil.copy(file,destination)
    os.chdir(currentdir)
else:
    print("source folder doesn't exist")