'''
write a program to read realestate.csv and display all the unique city names from the file with proper exception handling

Output:
SACRAMENTO
RIO LINDA
CITRUS HEIGHTS
'''

import csv
try:
    citydict = dict()
    with open("realestate.csv") as fobj:
        header = fobj.readline()
        #convert file object to csv object
        reader = csv.reader(fobj)
        #processing
        for line in reader:
            city = line[1]
            # create new key:value pairs
            citydict[city] = 1
        # display output
        for city in citydict:
            print(city)
except FileNotFoundError as err:
    print(err)
except Exception as err:
    print(err)





import csv
try:
    cityset = set()
    with open("realestate.csv") as fobj:
        header = fobj.readline()
        #convert file object to csv object
        reader = csv.reader(fobj)
        #processing
        for line in reader:
            city = line[1]
            cityset.add(city)
        # display output
        for city in cityset:
            print(city)
except FileNotFoundError as err:
    print(err)
except Exception as err:
    print(err)
    
    
    
    
    
import csv
try:
    citylist = list()
    with open("realestate.csv") as fobj:
        header = fobj.readline()
        #convert file object to csv object
        reader = csv.reader(fobj)
        #processing
        for line in reader:
            city = line[1]
            citylist.append(city)
        # display output
        for city in set(citylist):
            print(city)
except FileNotFoundError as err:
    print(err)
except Exception as err:
    print(err)    