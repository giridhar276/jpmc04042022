



print(__name__)