


import requests
import json

#step1
server = "https://api.github.com/"
endpoint = "users/giridhar276/gists"
user = "giridhar276"

finalurl = server + endpoint
print(finalurl)

r = requests.get(finalurl, auth=(user,'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'))
print(r.status_code)


# step2
info = json.loads(r.text)
for item in info:
    gid = item["id"]
    print(gid)
    finalurl = server + "gists/" + gid
    print(finalurl)
    r1 = requests.delete(finalurl, auth=(user,'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'))
    print(r1)
    print(r1.text)
    print("-------------------------------")
    
    
    
    





import requests
import json

#step1
server = "https://api.github.com/"
endpoint = "users/giridhar276/gists"
user = "giridhar276"

finalurl = server + endpoint

r = requests.get(finalurl, auth=(user,'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'))
print(r.status_code)


# step2
info = json.loads(r.text)
for item in info:
    gid = item["id"]
    print(gid)
    finalurl = server + "gists/" + gid
    print(finalurl)
    r1 = requests.delete(finalurl, auth=(user,'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'))
    print(r1)
    print(r1.text)
    print("-------------------------------")
    
    