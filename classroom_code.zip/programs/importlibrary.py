

# all the methods will be imported to program space
import math
print(math.tan(2))
print(math.floor(43.2))


# importing with alias name
import matplotlib.pyplot as plt
plt.plot([10,20],[20,30])

import  math as m
print(m.tan(2))

# importing required methods
# . is not required 
from math import tan,ceil,log
print(tan(1))
print(ceil(3.1))
print(log(2))

# not generally suggested .. 
from math import *
print(tan(1))
print(ceil(3.1))
print(log(2))


