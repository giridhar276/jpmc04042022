
import boto3
aws_mag_con=boto3.session.Session(profile_name="user30")
ec2_con_cli=aws_mag_con.client(service_name="ec2")


response=ec2_con_cli.describe_instances()

print(response)


response=ec2_con_cli.describe_instances()['Reservations']
for each_item in response:
	for each in each_item['Instances']:
		print("=============================")
		print("The Image Id is: {}\nThe Instance Id Is: {}\nThe Instance Launch Time is: {}".
        format(each['ImageId'],each['InstanceId'],each['LaunchTime'].strftime("%Y-%m-%d")))




    