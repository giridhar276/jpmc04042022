import pymysql
class Database:
    def __init__(self,hostname,port,username,password,database):
        self.hostname = hostname
        self.port = port
        self.username = username
        self.password = password 
        self.database = database
    
    def connect(self):
        try:
            self.db = pymysql.connect(host=self.hostname,port=self.port,user=self.username,password=self.password ,database=self.database)
            print(self.db)
        except pymysql.err.InternalError as err:
            print(err)
        except Exception as err:
            print(err)
            
    def createCursor(self):
        self.cursor = self.db.cursor()
    def displayData(self):
        try:
            self.query = "select * from realestate"
            self.cursor.execute(self.query)
            for record in self.cursor.fetchall():
                print("Street :",record[0] )
                print("City   :",record[1])
        except pymysql.err.DataError as err:
            print(err)
    def closeConnection(self):
        self.db.close()
    

if __name__ == "__main__":
    db1 = Database('localhost',3306,'root','india@123','jpmc')
    db1.connect()
    db1.createCursor()
    db1.insertData()
    #db1.displayData()
    #db1.closeConnection()
    
    
    
    
    