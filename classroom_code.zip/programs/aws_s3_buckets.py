## 
#create  bucket
import boto3
import os

session=boto3.session.Session(profile_name="user30")
client = session.client(service_name = "s3")
bucket_name = "giri12042022"   # replace the bucketname
location = {'LocationConstraint': 'ap-southeast-2'}
response = client.create_bucket(Bucket=bucket_name, CreateBucketConfiguration=location)
print("Amazon S3 bucket has been created")






# display buckets
# Retrieve the list of existing buckets
session=boto3.session.Session(profile_name="user30")
client = session.client("s3")
response = client.list_buckets()

# Output the bucket names
print('Existing buckets:')
for bucket in response['Buckets']:
    print(bucket["Name"])






## uploading all the files to bucket
import os
session=boto3.session.Session(profile_name="user30")
s3 = session.client("s3")

for file in os.listdir():
    if os.path.isfile(file):
        if file.endswith(".py"):
            print("Uploading :",file)
            s3.upload_file(file,'examples12042022g',file)
            
           
            
## uploading all the file to bucket           
import os
session=boto3.session.Session(profile_name="user30")
s3 = session.client("s3")            
s3.upload_file('realestate_new.csv','giri12042022','realestate_new.csv')           
            
           
            
# downloading file
import os
session=boto3.session.Session(profile_name="user30")
s3 = session.resource("s3")
s3.Bucket('giri12042022').download_file( 'realestate.csv','realestate_giri.csv')