



import boto3

console = boto3.session.Session(profile_name = "user30")
print(console)

# using resource
iam_console = console.resource('iam')
for user in iam_console.users.all():
    #print(type(user))
    print(user.name)
    print("--------")
    
    
# using client
import boto3

console = boto3.session.Session(profile_name = "user30")
print(console)
client = console.client(service_name = 'iam')

for user in client.list_users()['Users']:
    print(user)
    print(user['UserName'])
    
    
    

