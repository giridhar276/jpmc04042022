



# every class contains data members and member functions
class Employee:
    def getemployee(self):
        print("this is getemployee() method")
    
    def displayEmployee(self):
        print("this is displayemployee() method")
        
        
# object creation 
# object initialiation
emp1 = Employee()
emp1.getemployee()
emp1.displayEmployee()


emp2 = Employee()
emp2.getemployee()
emp2.displayEmployee()