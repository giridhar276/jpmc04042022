


import sys

try:
    with open("languag111.txt","r") as fobj:
        for line in fobj:
            line = line.strip()    # remove whitespaces if any
            print(line)
except Exception as err:
    print(err)
    


data = { "name"   : "John Smith",
  "sku"    : "20223",
  "price"  : 23.95,
  "shipTo" : { "name" : "Jane Smith",
               "address" : "123 Maple Street",
               "city" : "Pretendville",
               "state" : "NY",
               "zip"   : "12345" },
  "billTo" : { "name" : "John Smith",
               "address" : "123 Maple Street",
               "city" : "Pretendville",
               "state" : "NY",
               "zip"   : "12345" }
}

for key,value in data.items():
    print(key)
    print(len(key) * "-")
    if not isinstance(value,dict):
        print(value)    
    elif isinstance(value,dict):
        values = list(value.values())
        print(",".join(values))