


import os

#print(os.listdir())


for file in os.listdir():
    print(file)