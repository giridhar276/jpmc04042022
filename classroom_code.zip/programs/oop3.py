
# constructor will be invoked automatically when the object is created

# every class contains data members and member functions
class Employee:
    def __init__(self,name,age,location):
        self.name = name   
        self.age = age
        self.location = location
    
    def displayEmployee(self):
        print("Name :",self.name)
        print("Age  :", self.age)
        print("Location :",self.location)
        
# object creation 
# object initialiation
emp1 = Employee('Ram',30,"Hyd")
emp1.displayEmployee()


emp2 = Employee('Rita',25,"US")
emp2.displayEmployee()