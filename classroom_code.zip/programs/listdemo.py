#list: contains set of elements
# elments can be set of numbers or strings or any comb
# list elements are defined in []

alist = [10,20,30,40,3,56,32,56]
blist = ["unix","python",45,43,676,65.4543]


# add 45 to the list - adding single object
print(alist.append(90))
print('after appending :',alist)

# list.extend()  --> adding multiple values
alist.extend([21,32,43])
print("After extending :",alist)

# list.insert(index,position)
alist.insert(1,100)
print('After inserting :', alist)

# list.remove(value to be removed)
alist.remove(10)
print("After removing :",alist)

if 10 in alist:
    alist.remove(10)
else:
    print("10 doesn't exist")
    

getcount = alist.count(10)
if getcount > 0 :
    alist.remove(10)
    
   
alist.pop()   # last value will be removed
print(alist)    
   
#list.pop(index)
alist.pop(2)   #value at INDEX 2 will be removed
print(alist)
    
    
# list values in reverse order - in place
alist.reverse()
print(alist)


#
alist.sort()
print("After sorting :", alist)

alist.sort(reverse = True)
print("After sorting :", alist)

    
    

# iterating the list directly
for val in alist:
    print(val)
    


for index in range(0,len(alist)):
    print(alist[index])
