




import pymysql

try:
    #step1
    db = pymysql.connect(host='localhost',port=3306,user='root',password='india@123' ,database='jpmc')
    #print(db)
    if db:
        #for navigating the records
        cursor = db.cursor()
        #step2
        query = "select * from realestate"
        #step3
        cursor.execute(query)
        #step4
        for record in cursor.fetchall():
            print("Street :",record[0] )
            print("City   :",record[1])
        #step5
        db.close()
    else:
        print("Invalid connection")
    
except Exception as err:
    print(err)
    
    



# insert query
import pymysql

try:
    #step1
    db = pymysql.connect(host='localhost',port=3306,user='root',password='india@123' ,database = "jpmc")
    #print(db)
    if db:
        #for navigating the records
        cursor = db.cursor()
        #step2
        query = "insert into realestate values('{}','{}')".format("MG Road","Delhi")
        #step3
        cursor.execute(query)

        print(cursor.rowcount ,'row inserted')
        db.commit()
        db.close()
    else:
        print("Invalid connection")
    
except Exception as err:
    print(err)
    


#insert into realestate values('MG ROad','Delhi')






























