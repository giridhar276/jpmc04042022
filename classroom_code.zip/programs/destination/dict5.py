

data = { "name"   : "John Smith",
  "sku"    : "20223",
  "price"  : 23.95,
  "shipTo" : { "name" : "Jane Smith",
               "address" : "123 Maple Street",
               "city" : "Pretendville",
               "state" : "NY",
               "zip"   : "12345" },
  "billTo" : { "name" : "John Smith",
               "address" : "123 Maple Street",
               "city" : "Pretendville",
               "state" : "NY",
               "zip"   : "12345" }
}

for key,value in data.items():
    print(key)
    print(len(key) * "-")
    if not isinstance(value,dict):
        print(value)    
    elif isinstance(value,dict):
        values = list(value.values())
        print(",".join(values))

'''
Name
-----
John Smith

sku
----
20223

price
-----
23.95

shipTo
---------
Jane Smith, 123 Maple Street, Pretendville ,NY, 12345

billTo
--------
Jane Smith, 123 Maple Street, Pretendville ,NY, 12345
'''