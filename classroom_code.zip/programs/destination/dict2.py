
info = [
	{
		'color': "red",
		'value': "#f00"
	},
	{
		'color': "magenta",
		'value': "#f0f"
	},
	{
		'color': "yellow",
		'value': "#ff0"
	},
	{
		'color': "black",
		'value': "#000"
	}
]


for item in info:
    print(item['color'].ljust(10),item['value'])

#
'''
red     -  #f00
mangeta -  #f0f
yellow  -  #ff0
black   -  #000
'''