import os
try:
    for file in os.listdir():
        if file.endswith(".py"):
            print(file.ljust(30), os.path.getsize(file) ,"bytes")
except Exception as err:
    print(err)
    
    
 
    
 
import os
import re
try:
    for file in os.listdir():
        if re.search("py$",file):
            print(file.ljust(30), os.path.getsize(file) ,"bytes")
except Exception as err:
    print(err)