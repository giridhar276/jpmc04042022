
#fobj = open(r"D:\trainings\jpmc04042022\numbers.txt","w")  # raw string
#fobj = open("D:/trainings/jpmc04042022/numbers.txt","w")
#fobj = open("D:\\trainings\\jpmc04042022\\numbers.txt","w")

fobj = open("numbers.txt","w")

for val in range(1,10):
    fobj.write(str(val) + "\n")

fobj.close()





aset = {10,10,20,20,20,30}
bset = {30,30,30,30,40,50}

print(aset)
print(bset)

aset.add(10)
print(aset)
aset.add(50)
print(aset)

aset.union(bset)
print(aset.union(bset))


