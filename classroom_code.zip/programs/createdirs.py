

'''
Write a Python program to create 100 directories in the current directory.
dir1
dir2
dir3
..
..
dir100
'''

import os
for val in range(1,11):
    dirname = "dir" + str(val)
    os.mkdir(dirname)