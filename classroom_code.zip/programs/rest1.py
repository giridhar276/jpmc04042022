 
    
import requests
import json
 

url = 'https://api.github.com/'

endpoint = "user"

finalurl  = url + endpoint

response = requests.get(finalurl, auth = ("giridhar276","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"))

print(response)
if response.status_code == 200 :
    data = json.loads(response.text)
    for key,value in data.items():
        print(key.ljust(15), value)
else:
    print("Something went wrong")
    
    
    
url = 'https://api.github.com/'    
# all the users
endpoint = "users"
finalurl  = url + endpoint
response = requests.get(finalurl, auth = ("giridhar276","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"))
print(response.status_code)

if response.status_code == 200 :
    data = json.loads(response.text)
    for item in data:
        print(item['login'])
        print("--------")
        
        
        
        
        
    
url = 'https://api.github.com/'    
# all the users
endpoint = "users/giridhar276"
    
finalurl  = url + endpoint
response = requests.get(finalurl, auth = ("giridhar276","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"))

print(response.status_code)

if response.status_code == 200 :
    data = json.loads(response.text)
    print(data)
    

    
    


