

import boto3


aws_mag_con_root=boto3.session.Session(profile_name="user30")
ec2 = aws_mag_con_root.resource('ec2')

print(ec2)

instances = ec2.create_instances(
        ImageId="ami-059af0b76ba105e7e",
        MinCount=1,
        MaxCount=1,
        InstanceType="t2.micro"
    )


print(instances)



import boto3
aws_mag_con_root=boto3.session.Session(profile_name="user30")
ec2 = aws_mag_con_root.resource('ec2')

print(ec2)

instances = ec2.create_instances(
        ImageId="ami-09662e4f2b2fb67f9",
        MinCount=1,
        MaxCount=1,
        InstanceType="t2.micro"
    )

print(instances)    
    
    