import filecmp
import os

class FileCompare:
    def __init__(self,directory1,directory2):
        self.directory1 = directory1
        self.directory2 = directory2
        
    def displayDirectories(self):
        print(self.directory1)
        print(self.directory2)
        

    def returnObject(self):
        self.dcmp = filecmp.dircmp(self.directory1,self.directory2)
        
    def commonFiles(self):
        print("***** common files*****")
        allfiles = self.dcmp.common
        #print(allfiles)
        for file in allfiles:
            print(file)
        
    def onlyLHSFiles(self):
        print("***** files present at ",self.directory1)
        for file in self.dcmp.left_list:
            print(file)
        


if __name__ == "__main__":
    dir1 = r"D:\trainings\jpmc04042022\programs\Python27"
    dir2 = r"D:\trainings\jpmc04042022\programs\Python36"
    
    
    if os.path.isdir(dir1)  and os.path.isdir(dir2):
        obj = FileCompare(dir1,dir2)
        obj.displayDirectories()
        obj.returnObject()
        obj.commonFiles()
        obj.onlyLHSFiles()
    else:
        print("directories doesn't exist")