


import os
import subprocess

def ping(host):
    '''
    Sends 2 ICMPs to a host and suppress the output by sending it to devnull.
    
    Returns True if there was a response, False otherwise.
    '''
    with open(os.devnull, 'w') as devnull:
        result = subprocess.call(
            ['ping', '-c', '2', '-W', '2', host],
            stdout=devnull,
            stderr=devnull
            )
    print(result)       
    if result == 0:
        return True
    else:        
        return False


# host_list = [ 'server-{}'.format(nr) for nr in range(0, 10) ]

host_list = ["142.250.195." + str(nr) for nr in range(37, 47) ]

for host in host_list:
    print(host)
    print(ping(host))