import time

def decorator1(func):
    '''decorator to filter input list'''
    def wrapper(*args, **kwargs):
        # filter only even numbers
        args = [n for n in args if n%2 == 0]
        my_func = func(*args, **kwargs)
        return my_func
    return wrapper


def decorator2(func):
    '''decorator to mark execution points in decorator'''
    print('Do this on decorator entry')
    def wrapper(*args, **kwargs):
        print('Do this before function')
        my_func = func(*args, **kwargs)
        print('Do this after function')
        return my_func
    return wrapper


def decorator3(start_msg=None, end_msg=None, timer=False):
    '''decorator to optionally print start and end messages as well as execution time'''
    def inner_decorator(func):
        def wrapper(*args, **kwargs):
            if start_msg:
                print(start_msg)
            start = time.time()
            my_func = func(*args, **kwargs)
            end = time.time()
            if end_msg:
                print(end_msg)
            if timer:
                print(f'<Function finished in {end - start:0.3f}s>')
            return my_func
        return wrapper
    return inner_decorator


@decorator3(timer=True)
@decorator2
def hello(name):
    '''pauses and prints greeting'''
    time.sleep(0.1)
    print('Hello', name)


@decorator3('before add', 'after add', timer=True)
@decorator1
def add(*args):
    '''return sum of input arguments'''
    return sum(args)

hello('Bob')

print(add(*[1, 2, 3, 4, 5, 6, 7, 8, 9, 0]))