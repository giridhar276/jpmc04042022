

from abc import ABC, abstractmethod
class Demo1(ABC):
   @abstractmethod
   def m1(self):
       pass
   @abstractmethod
   def m2(self):
       pass
   def m3(self):
       print("Implemented method")